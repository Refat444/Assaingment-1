﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1; 


namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {

            ClassLibrary1.Address address = new ClassLibrary1.Address("208", "ty/90", "Dhaka", "Bangladesh");
            Account account1 = new Account("Al Amin",2000.00,address);
            account1.ShowAccountInformation();

            ClassLibrary1.Address address = new ClassLibrary1.Address("209", "ty/70", "Rajshahi", "Bangladesh");
            Account account2 = new Account("Arika", 1000.00);
            account2.ShowAccountInformation();

        }
    }
}
